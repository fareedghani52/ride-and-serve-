export const FareDetailsData = [
  {
    Cab_Type: "SUV",
    Price_km: "100rs",
    Price_minute: "150rs",
    Base_fare: "1000rs",
    Commision: "20%",
  },
  {
    Cab_Type: "SEDAN",
    Price_km: "120rs",
    Price_minute: "170rs",
    Base_fare: "1200rs",
    Commision: "25%",
  },
  {
    Cab_Type: "Crossover",
    Price_km: "80rs",
    Price_minute: "120rs",
    Base_fare: "1100rs",
    Commision: "15%",
  },
  {
    Cab_Type: "Coupe",
    Price_km: "100rs",
    Price_minute: "150rs",
    Base_fare: "1000rs",
    Commision: "20%",
  },
  {
    Cab_Type: "Van",
    Price_km: "70rs",
    Price_minute: "100rs",
    Base_fare: "1000rs",
    Commision: "10%",
  },
  {
    Cab_Type: "Wagon",
    Price_km: "70rs",
    Price_minute: "90rs",
    Base_fare: "1500rs",
    Commision: "22%",
  },
];
