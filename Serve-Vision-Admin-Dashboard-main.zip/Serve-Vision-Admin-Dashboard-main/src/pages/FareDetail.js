import React from "react";
// import { FareDetailsData } from "../Components/FareDetailsData";
import * as CiIcons from "react-icons/ci";
import * as MdIcons from "react-icons/md";
import axios from "axios"
const FareDetail = () => {

  //faredetais get api code
const [faredetails, setFaredetails] = React.useState([])
React.useEffect( () => {
  let processing = true
  axiosFetchData(processing)
  return () => {
      processing = false
  }
},[])

const axiosFetchData = async(processing) => {
  await axios.get('faredetails')
  .then(res => {
      if (processing) {
        setFaredetails(res.data)
      }
  })
  .catch(err => console.log(err))
}
//


  return (
    <div className="page-container">
      <div class="table-responsive " style={{ margin: "30px" }}>
        <header
          className="p-4 bg-white mt-4"
          style={{ borderBottom: "1px solid black" }}
        >
          <h4>Fare Details</h4>
        </header>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Cab Type</th>
              <th scope="col">Price/km</th>
              <th scope="col">Price/minute</th>
              <th scope="col">Base Fare</th>
              <th scope="col">Commission</th>
              <th scope="col">Action</th>
            </tr>
          </thead>

          {
          // FareDetailsData maping via api
          faredetails?.map((item, index) => (
            <tbody>
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{item.Cab_Type}</td>
                <td>{item.Price_km}</td>
                <td>{item.Price_minute}</td>
                <td>{item.Base_fare}</td>
                <td>{item.Commision}</td>
                <td>
                  <button
                    style={{
                      borderRadius: "20%",
                      padding: "2px ",
                      background: "white",
                    }}
                  >
                    <CiIcons.CiEdit />
                  </button>

                  <button
                    style={{
                      borderRadius: "20%",
                      padding: "2px ",
                      background: "red",
                    }}
                  >
                    <MdIcons.MdOutlineDeleteOutline />
                  </button>
                </td>
              </tr>
            </tbody>
          ))}
        </table>
      </div>
    </div>
  );
};

export default FareDetail;
