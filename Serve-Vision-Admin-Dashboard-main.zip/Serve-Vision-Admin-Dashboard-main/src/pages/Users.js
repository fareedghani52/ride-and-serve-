import React, { useState, useEffect } from "react";
import axios from "axios";
const Users = () => {
  const [users, setUsers] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [error, setError] = useState("");
  const [newUser, setNewUser] = useState({
    userfname: "",
    userlname: "",
    role: "Driver",
    useremail: "",
  });

  const handleSaveUser = (e) => {
    e.preventDefault();
    // Add the new user to the user list (you may want to perform data validation here)
    setUsers([...users, newUser]);
    setError("");
    axiosPostData();
    console.log(newUser);
    // Reset the new user input fields
    setNewUser({
      userfname: "",
      userlname: "",
      role: "Driver",
      useremail: "",
    });
  };
  //get api code
  const [datausers, setDatausers] = React.useState([]);
  useEffect(() => {
    setUsers(datausers);
    let processing = true;
    axiosFetchData(processing);
    return () => {
      processing = false;
    };
  }, []);

  const axiosFetchData = async (processing) => {
    await axios
      .get("getusers")
      .then((res) => {
        if (processing) {
          console.log(res.data.data);
          setDatausers(res.data.data);
        }
      })
      .catch((err) => console.log(err));
  };
  /////////////////////////
  //delete api code
  const deleteUser = async (id) => {
    // console.log(id);
    let processing = true;
    try {
      const res = await axios.delete(`deleteuser/${id}`);
      alert(res.data.message);
      console.log(res.data);
    } catch (error) {
      console.error(error);
    }
    axiosFetchData(processing);
    return () => {
      processing = false;
    };
  };
  //update api code
  const updateuser = async (data) => {
    console.log(data)
    let processing = true;
    try {
      const res = await axios.put(`updateuser`, { newData: data });
      alert(res.data.message);
      console.log(res.data);
    } catch (error) {
      console.error(error);
    }
    axiosFetchData(processing);
    return () => {
      processing = false;
    };
  }  
  //post api code
  const axiosPostData = async () => {
    let processing = true;
    const fullName = `${newUser.userfname} ${newUser.userlname}`;
    const postData = {
      username: fullName,
      role: newUser.role,
      useremail: newUser.email,
    };
    await axios
      .post("add/user", postData)
      .then((res) => alert(res.data.message))
      .catch(
        (err) => alert(err)
        // setError(<p className="required">{err}</p>)
      );
    axiosFetchData(processing);
    return () => {
      processing = false;
    };
  };
  // useEffect(() => {
  //   // Simulate fetching user data from an API
  //   setUsers(initialUsers);
  // }, []);
  //((((()))))
  const handleSearch = (e) => {
    setSearchText(e.target.value);
  };
  const filteredUsers = datausers.filter((user) =>
    user.username.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="page-container">
      <h2 className="text-muted d-flex justify-content-center align-items-center">
        User Management
      </h2>
      <h2 className="d-flex justify-content-center align-items-center">
        {error}
      </h2>
      <div className="d-flex justify-content-center align-items-center">
        <form className="col-lg-8" onSubmit={handleSaveUser}>
          <div class="form-group col-lg-12">
            <h5 className="font-weight-normal">
              Add Record for required* fields
            </h5>
          </div>
          <div className="row">
            <div class="form-group col-lg-6">
              <label className="required">*</label>
              <input
                type="text"
                class="form-control "
                id="firstname"
                placeholder="Enter First Name"
                required
                pattern="[A-Za-z]+"
                value={newUser.userfname || ""}
                onChange={(e) =>
                  setNewUser({ ...newUser, userfname: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6">
              <label className="required">*</label>
              <input
                type="text"
                class="form-control "
                id="lastname"
                placeholder="Enter Last Name"
                required
                pattern="[A-Za-z]+"
                value={newUser.userlname || ""}
                onChange={(e) =>
                  setNewUser({ ...newUser, userlname: e.target.value })
                }
              />
            </div>
          </div>
          <div class="form-group col-lg-12 pb-2">
            <label className="required">*</label>
            <input
              type="email"
              class="form-control br-20"
              id="email"
              placeholder="Enter email"
              required
              value={newUser.email || ""}
              onChange={(e) =>
                setNewUser({ ...newUser, email: e.target.value })
              }
            />
          </div>
          <div class="form-group col-lg-12 pb-2">
            <select
              required
              value={newUser.role || ""}
              class="form-control br-20"
              onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}
            >
              <option value="admin">Admin</option>
              <option value="driver">
                Driver
              </option>
              <option value="passenger">Passenger</option>
            </select>
          </div>
          <div class="form-group col-lg-12">
            <button
              type="submit"
              className="form-control btn btn-success "
              // onClick={handleSaveUser}
            >
              <h5> Add New User</h5>
            </button>
          </div>
        </form>
      </div>
      <div className="search d-flex justify-content-center align-items-center mt-3">
        <input
          className="p-2 mb-4"
          type="search"
          placeholder="Search Users by name"
          value={searchText}
          onChange={handleSearch}
          style={{ border: "black 4px solid", borderRadius: "20px" }}
        />
      </div>

      <div class="table-responsive">
        <table class="table table-success table-striped-columns">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Role</th>
              <th scope="col">Email</th>
              <th scope="col">Registration Date</th>
              <th scope="col">Action</th>
            </tr>
          </thead>

          <tbody>
            {filteredUsers.map((user, index) => (
              <tr key={index}>
                <th scope="row">{index + 1}</th>

                <td>{user.username}</td>
                <td>{user.role}</td>
                <td>{user.useremail}</td>
                <td>
                  {user.createdAt.split("T").shift() /*.split(".").shift()*/}
                </td>
                <td>
                  <button
                    onClick={() => deleteUser(user._id)}
                    style={{
                      backgroundColor: "transparent",
                      border: "none",
                      padding: "2px",
                    }}
                  >
                    {" "}
                    ⛔
                  </button>
                  <button
                    onClick={() => updateuser(user._id)}
                    style={{
                      backgroundColor: "transparent",
                      border: "none",
                      padding: "2px",
                    }}
                  >
                    {" "}
                    
                    +
                  </button>
                  <select onChange={(e)=> updateuser(user._id, e.target.value)} value={user.role}>
                    <option value="admin">Admin</option>
                    <option value="driver">Driver</option>
                    <option value="passenger">Passenger</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Users;
