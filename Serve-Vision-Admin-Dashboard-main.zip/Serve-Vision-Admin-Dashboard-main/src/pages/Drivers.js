import React, { useState } from "react";
// import { DriversData } from "../Components/DriversData";
import axios from 'axios';
const Drivers = () => {
  const [viewItemIndex, setViewItemIndex] = useState(null);
  const indexupdate = (index) => {
    setViewItemIndex(index);
  };
  function getStatusClass(status) {
    switch (status) {
      case "Pending":
        return "bg-primary text-white"; // Blue background
      case "Blocked":
        return "bg-danger text-white "; // Red background
      case "Active":
        return "bg-success text-white"; // Green background
      default:
        return ""; // Default background (no specific color)
    }
  }

//rides details get api code
const [datadrivers, setDatadrivers] = React.useState([])
React.useEffect( () => {
  let processing = true
  axiosFetchData(processing)
  return () => {
      processing = false
  }
},[])

const axiosFetchData = async(processing) => {
  await axios.get('driversdata')
  .then(res => {
      if (processing) {
        setDatadrivers(res.data)
      }
  })
  .catch(err => console.log(err))
}
//

  return (
    <div className="page-container">
      <div className="row align-item-center justify-content-center">
        <div
          className="card text-bg-secondary m-3"
          style={{ maxWidth: "18rem" }}
        >
          <div className="card-header">Drivers</div>
          <div className="card-body">
            <h5 className="card-title">Total Drivers Registered</h5>
            <p className="card-text"> 32</p>
          </div>
        </div>
        <div className="card text-bg-danger m-3" style={{ maxWidth: "18rem" }}>
          <div className="card-header">Drivers</div>
          <div className="card-body">
            <h5 className="card-title">Blocked Drivers</h5>
            <p className="card-text"> 32</p>
          </div>
        </div>
      </div>
      <br />

      <table class="table  shadow ">
        <thead className="thread">
          <tr>
            <th scope="col">
              <h3>#</h3>
            </th>
            <th scope="col">
              <h4>Name</h4>
            </th>
            <th scope="col">
              <h4>Contact</h4>
            </th>
            <th scope="col">
              <h4>Status</h4>
            </th>
            <th scope="col">
              <h4>Action</h4>
            </th>
          </tr>
        </thead>
        {datadrivers.map((item, index) => (
          <tbody>
            <tr>
              <td>
                <h4 className="p-2">{index + 1}</h4>
              </td>

              <td>
                <h6 className="p-3">{item.Driver_Name}</h6>
              </td>
              <td>
                <h6 className="p-3">{item.Driver_Contact}</h6>
              </td>
              <td>
                <h6
                  className={`p-3 ${getStatusClass(item.Driver_Status)}`}
                  style={{ borderRadius: "20px", width: "85px" }}
                >
                  {item.Driver_Status}
                </h6>
              </td>
              <td className="p-3">
                <button
                  type="button"
                  class="btn btn-secondary"
                  style={{ borderRadius: "15px" }}
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal1"
                  onClick={() => indexupdate(index)}
                >
                  View Detail
                </button>
              </td>
            </tr>
          </tbody>
        ))}
      </table>

      <div
        class="modal fade"
        id="exampleModal1"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title fs-5" id="exampleModalLabel">
                Details
              </h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body d-flex col-12">
              <div className="Cab-detail col-6">
                <h3 className="text-muted">Driver Details</h3>
                <br />
                <h6>
                  Driver Name:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Driver_Name
                    : ""}
                  <br />
                  Driver Contact:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Driver_Contact
                    : ""}
                  <br />
                  Drivers Cnic:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Driver_Cnic
                    : ""}
                  <br />
                  Vehical Category:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Vehicle_Category
                    : ""}
                  <br />
                  Vehical Model:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Vehicle_Model
                    : ""}
                  <br />
                  Driver Address:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Driver_Address
                    : ""}
                  <br />
                  Registered Date:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Date_of_Registeration
                    : ""}
                  <br />
                  Rides Completed:
                  {viewItemIndex !== null
                    ? " " + datadrivers[viewItemIndex].Total_rides_completed
                    : ""}
                </h6>
              </div>
              <div className="picture">
                <h3 className="text-muted">Driver Picture</h3>
                {viewItemIndex !== null
                  ? " " + datadrivers[viewItemIndex].Driver_picture
                  : ""}
              </div>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Drivers;
