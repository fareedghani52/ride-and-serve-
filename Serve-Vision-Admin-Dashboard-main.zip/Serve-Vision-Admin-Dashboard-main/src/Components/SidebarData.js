import React from "react";
import * as BsIcons from "react-icons/bs";
import * as FaIcons from "react-icons/fa";
import * as RxIcons from "react-icons/rx";
import * as FcIcons from "react-icons/fc";
export const SidebarData = [
  {
    title: "Dashboard",
    path: "/",
    icon: <RxIcons.RxDashboard />,
    cName: "nav-text",
  },
  {
    title: "Users",
    path: "/users",
    icon: <BsIcons.BsFillPersonCheckFill />,
    cName: "nav-text",
  },
  {
    title: "Drivers",

    path: "/drivers",
    icon: <FaIcons.FaCarSide />,
    cName: "nav-text",
    subItems: [
      {
        title: "Add Driver",
        path: "/add-drivers",
        icon: <FaIcons.FaCarSide />,
        cName: "nav-text",
      },
    ],
  },
  {
    title: "Fare Details",
    path: "/faredetails",
    icon: <FaIcons.FaRegMoneyBillAlt />,
    cName: "nav-text",
  },
  {
    title: "Rides",
    path: "/rides",
    icon: <FcIcons.FcRating />,
    cName: "nav-text",
  },
];
