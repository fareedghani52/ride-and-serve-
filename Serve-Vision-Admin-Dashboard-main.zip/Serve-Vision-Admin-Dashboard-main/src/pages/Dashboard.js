import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Charts from "../Components/Charts";
// import { RidesData } from "../Components/RidesData";
import FareDetail from "./FareDetail";
import axios from "axios"
const Dashboard = () => {
  //rides details for dashboard get api code
  const [datarides, setDataRides] = React.useState([])
  React.useEffect( () => {
    let processing = true
    axiosFetchData(processing)
    return () => {
        processing = false
    }
},[])
  const axiosFetchData = async(processing) => {
    await axios.get('datarides')
    .then(res => {
        if (processing) {
            setDataRides(res.data)
        }
    })
    .catch(err => console.log(err))
}
//
  return (
    <div className="page-container">
      <div className="card-container d-flex">
        <div className="container bg-light  ml-5">
          <h4>Site Statistics</h4>
          <div className="row">
            <div className="col ">
              <div
                className="card text-bg-primary mb-3 "
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Rides</div>
                <div className="card-body">
                  <h5 className="card-title">Total Montly Contracts</h5>
                  <p className="card-text">40</p>
                </div>
              </div>
            </div>

            <div className="col">
              <div
                className="card text-bg-secondary mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Drivers</div>
                <div className="card-body">
                  <h5 className="card-title">Total Drivers Registered</h5>
                  <p className="card-text"> 32</p>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col ">
              <div
                className="card text-bg-success mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Vehicle</div>
                <div className="card-body">
                  <h5 className="card-title">Vehicle Types</h5>
                  <p className="card-text">6</p>
                </div>
              </div>
            </div>

            <div className="col">
              <div
                className="card text-bg-danger mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Drivers</div>
                <div className="card-body">
                  <h5 className="card-title">Blocked Drivers</h5>
                  <p className="card-text">10</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container bg-light ">
          <h4>Ride Statistics</h4>

          <div className="row ">
            <div className="col ">
              <div
                className="card text-bg-primary mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Rides</div>
                <div className="card-body">
                  <h5 className="card-title">Total No of Rides</h5>
                  <p className="card-text">40</p>
                </div>
              </div>
            </div>

            <div className="col">
              <div
                className="card text-bg-secondary mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Rides</div>
                <div className="card-body">
                  <h5 className="card-title">On-Going Rides </h5>
                  <p className="card-text"> 32</p>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col ">
              <div
                className="card text-bg-success mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Rides</div>
                <div className="card-body">
                  <h5 className="card-title">Completed Rides</h5>
                  <p className="card-text">15</p>
                </div>
              </div>
            </div>

            <div className="col">
              <div
                className="card text-bg-danger mb-3"
                style={{ maxWidth: "18rem" }}
              >
                <div className="card-header">Rides</div>
                <div className="card-body">
                  <h5 className="card-title">Cancelled Rides </h5>
                  <p className="card-text"> 32</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Charts />

      <div
        className="d-flex align-item-center justify-content-center"
        style={{ maxWidth: "100%" }}
      >
        <div
          className="bg-white d-flex flex-column align-item-center justify-content-center"
          style={{ maxWidth: "1300px" }}
        >
          <header className="p-2" style={{ borderBottom: "1px solid black" }}>
            {" "}
            <h4>Cabs Lives location</h4>
          </header>
          <div className="m-1">
            <img
              src={process.env.PUBLIC_URL + "/cabLocations.png"}
              alt="location"
              className="fixed-left m-2"
            />
          </div>
        </div>
      </div>
      <div>
        <div className="d-flex align-item-center justify-content-center">
          <div className="fare" style={{ width: "800px" }}>
            <FareDetail />
          </div>
          <div style={{ width: "700px" }}>
            <header
              className="p-4 bg-white mt-4"
              style={{ borderBottom: "1px solid black" }}
            >
              <h4>Recent Rides</h4>
            </header>
            <table class="table  shadow ">
              <thead className="thread">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Date Booked</th>
                  <th scope="col">Name</th>
                  <th scope="col">PickUp Location</th>
                  <th scope="col">Drop Location</th>
                </tr>
              </thead>

              {datarides.map((item, index) => (
                <tbody>
                  <tr>
                    <td>{index + 1}</td>

                    <td>{item.Date} </td>
                    <td>{item.Rider_Name}</td>
                    <td>{item.Pickup_Loc}</td>
                    <td>{item.Dropoff_Loc}</td>
                  </tr>
                </tbody>
              ))}
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
