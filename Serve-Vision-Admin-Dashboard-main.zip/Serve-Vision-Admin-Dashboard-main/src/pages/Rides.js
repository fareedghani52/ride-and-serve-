import React from "react";
// import { RidesData } from "../Components/RidesData";
import * as MdIcons from "react-icons/md";
import { useState } from "react";
import axios from "axios"
const Rides = () => {
  const [viewItemIndex, setViewItemIndex] = useState(null);
  const indexupdate = (index) => {
    setViewItemIndex(index);
  };

  function getStatusClass(status) {
    switch (status) {
      case "on-going":
        return "bg-primary text-white"; // Blue background
      case "canceled":
        return "bg-danger text-white"; // Red background
      case "completed":
        return "bg-success text-white"; // Green background
      default:
        return ""; // Default background (no specific color)
    }
  }
//rides details get api code
  const [datarides, setDataRides] = React.useState([])
  React.useEffect( () => {
    let processing = true
    axiosFetchData(processing)
    return () => {
        processing = false
    }
},[])

  const axiosFetchData = async(processing) => {
    await axios.get('datarides')
    .then(res => {
        if (processing) {
            setDataRides(res.data)
        }
    })
    .catch(err => console.log(err))
}
//
  return (
    <div className="page-container-rides">
      <div>
        <h1 className="text-muted">Rides Data</h1>
      </div>
      <div>
        <table class="table  shadow ">
          <thead className="thread">
            <tr>
              <th scope="col">
                <h3>#</h3>
              </th>
              <th scope="col">
                <h4>Date Booked</h4>
              </th>
              <th scope="col">
                <h4>Name</h4>
              </th>
              <th scope="col">
                <h4>Status</h4>
              </th>
              <th scope="col">
                <h4>Action</h4>
              </th>
            </tr>
          </thead>
          {datarides.map((item, index) => (
            <tbody>
              <tr>
                <td>
                  <h4 className="p-2">{index + 1}</h4>
                </td>

                <td>
                  <h6 className="p-3">{item.Date}</h6>
                </td>
                <td>
                  <h6 className="p-3">{item.Rider_Name}</h6>
                </td>
                <td>
                  <h6
                    className={`p-3 ${getStatusClass(item.status)}`}
                    style={{ borderRadius: "15px", maxWidth: "110px" }}
                  >
                    {item.status}
                  </h6>
                </td>
                <td className="p-3">
                  <button
                    type="button"
                    class="btn btn-success"
                    style={{ borderRadius: "15px" }}
                    data-bs-toggle="modal"
                    data-bs-target="#exampleModal"
                    onClick={() => indexupdate(index)}
                  >
                    View Detail
                  </button>
                </td>
              </tr>
            </tbody>
          ))}
        </table>
      </div>

      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title fs-5" id="exampleModalLabel">
                Booking Details
              </h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div>
              <div class="modal-body d-flex col-12">
                <div className="Cab-detail col-6">
                  <h3 className="text-muted">Cab Details</h3>
                  <br />
                  <h6>
                    Cab Body No:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Cab_body_no
                      : ""}
                    <br />
                    Vehicle Category:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Vehicle_Category
                      : ""}
                    <br />
                    Vehicle Model:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Vehicle_Model
                      : ""}
                    <br />
                    Driver:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Driver_Name
                      : ""}
                    <br />
                    Driver Contact:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Driver_Contact
                      : ""}
                    <br />
                    Driver Address:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Driver_Address
                      : ""}
                  </h6>
                </div>
                <div className="Booking-Detail col-6">
                  <h3 className="text-muted">Booking Details</h3>
                  <br />
                  <h6>
                    Booking No:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Booking_no
                      : ""}
                    <br />
                    Pickup Zone:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Pickup_Loc
                      : ""}
                    <br />
                    DropOff Zone:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Dropoff_Loc
                      : ""}
                    <br />
                    Status:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].status
                      : ""}
                    <br />
                    Pickup_Time:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Pickup_Time
                      : ""}
                    <br />
                    Return_Time:
                    {viewItemIndex !== null
                      ? " " + datarides[viewItemIndex].Return_Time
                      : ""}
                    <br />
                  </h6>
                </div>
              </div>
              <div className="d-flex align-item-center justify-content-center">
                <div
                  className="card mb-4"
                  style={{
                    width: "22rem",
                    boxShadow: "#51575c9e 0px 0px 10px 1px",
                  }}
                >
                  {viewItemIndex !== null ? (
                    <img
                      src={
                        process.env.PUBLIC_URL +
                        "/" +
                        datarides[viewItemIndex].loc
                      }
                      alt="location"
                      style={{ maxWidth: "498px" }}
                    />
                  ) : (
                    ""
                  )}
                  <div class="card-body">
                    <p class="card-text">
                      <MdIcons.MdDateRange />
                      {viewItemIndex !== null
                        ? ": " + datarides[viewItemIndex].Date
                        : ""}
                      <br />
                      <div style={{ marginLeft: "-19px" }}>
                        {" "}
                        <span
                          style={{
                            borderRadius: "50%",
                            backgroundColor: "#86b7fe",
                            padding: "0px 6px 3px 6px",
                            color: "black",
                          }}
                        >
                          A
                        </span>
                        {viewItemIndex !== null
                          ? ": " + datarides[viewItemIndex].Pickup_Loc
                          : ""}
                        <br />
                        <span
                          style={{
                            borderRadius: "50%",
                            backgroundColor: "lightgreen",
                            padding: "0px 6px 3px 6px",
                            color: "black",
                          }}
                        >
                          B
                        </span>
                        {viewItemIndex !== null
                          ? ": " + datarides[viewItemIndex].Dropoff_Loc
                          : ""}
                        <br />
                      </div>
                      RS
                      {viewItemIndex !== null
                        ? ": " + datarides[viewItemIndex].payment
                        : ""}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              {viewItemIndex !== null &&
              datarides[viewItemIndex].status === "on-going" ? (
                <button type="button" class="btn btn-light">
                  Watch Live Video
                </button>
              ) : (
                ""
              )}

              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Rides;
