import React from "react";
import axios from "axios";
import { nanoid } from "nanoid";
const AddDrivers = () => {
  const [error, setError] = React.useState("");
  const [newDriver, setNewDriver] = React.useState({
    id: "",
    firstname: "",
    lastlname: "",
    streetaddress1: "",
    streetaddress2: "",
    city: "",
    zipcode: "",
    email: "",
phonenumber: "",
    Gender: "",
    picture: "not available",
    vehicalnumber: "",
    vehicaltype: "",
    vehicalmodel: "",
    seatingcapacity: "",
    vehicaldocs: "not available",
  });

  const handleSaveUser = (e) => {
    e.preventDefault()
    // Add the new user to the user list (you may want to perform data validation here)
    newDriver.id = nanoid();
    // setNewDriver([...driver, newUser]);
    if (!newDriver.email) {
      setError(
        <p className="required">
          Email is empty. Please provide a valid email.
        </p>
      );
    } else {
      setError("");
      axiosPostData();
      console.log(newDriver);
      // Reset the new user input fields
      setNewDriver({
        id: "",
    firstname: "",
    lastlname: "",
    streetaddress1: "",
    streetaddress2: "",
    city: "",
    zipcode: "",
    email: "",
    phonenumber: "",
    Gender: "",
    picture: "not available",
    vehicalnumber: "",
    vehicaltype: "",
    vehicalmodel: "",
    seatingcapacity: "",
    vehicaldocs: "not available",
      });
    }
  };

  //post api code
  const axiosPostData = async () => {
    const postData = {
      id: newDriver.id,
    firstname: newDriver.firstname,
    lastname: newDriver.lastname,
    streetaddress1: newDriver.streetaddress1,
    streetaddress2: newDriver.streetaddress2,
    city: newDriver.city,
    zipcode: newDriver.zipcode,
    email: newDriver.email,
    phonenumber: newDriver.phonenumber,
    Gender: newDriver.Gender,
    picture: newDriver.picture,
    vehicalnumber: newDriver.vehicalnumber,
    vehicaltype: newDriver.vehicaltype,
    vehicalmodel: newDriver.vehicalmodel,
    seatingcapacity: newDriver.seatingcapacity,
    vehicaldocs: newDriver.vehicaldocs,
    };

    await axios
      .post("add/driver", postData)
      .then((res) => setError(<p className="success">{res.data}</p>));
  };

  return (
    <div className="page-container">
      <h2 className="d-flex justify-content-center align-items-center">{error}</h2>
      <div className="d-flex justify-content-center align-items-center">
        <form className="col-lg-8" onSubmit={handleSaveUser}>
          <div class="form-group col-lg-12 p-3 ">
            <h5>Basic Information</h5>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter First Name"
                id="firstname"
                required
                pattern="[A-Za-z]+"
                value={newDriver.firstname || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, firstname: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter Last Name"
                id="lastname"
                required
                pattern="[A-Za-z]+"
                value={newDriver.lastname || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, lastname: e.target.value })
                }
              />
            </div>
          </div>
          <div className="row">
          <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter Street Address 1"
                id="streetaddress1"
                required
                pattern="[A-Za-z]+"
                value={newDriver.streetaddress1 || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, streetaddress1: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter Street Address 2"
                id="streetaddress2"
                required
                pattern="[A-Za-z]+"
                value={newDriver.streetaddress2 || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, streetaddress2: e.target.value })
                }
              />
            </div>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter City"
                id="city"
                required
                pattern="[A-Za-z]+"
                value={newDriver.city || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, city: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6 p-1">
              <input
                type="number"
                class="form-control pt-4 pb-4"
                placeholder="Enter ZipCode"
                id="zipcode"
                required
                pattern="[A-Za-z]+"
                value={newDriver.zipcode || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, zipcode: e.target.value })
                }
              />
            </div>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <input
                type="email"
                class="form-control pt-4 pb-4"
                placeholder="Enter Email"
                id="email"
                required
                value={newDriver.email || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, email: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6 p-1">
              <input
                type="number"
                class="form-control pt-4 pb-4"
                placeholder="Enter Phone Number"
                id="phonenumber"
                required
                pattern="[A-Za-z]+"
                value={newDriver.phonenumber || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, phonenumber: e.target.value })
                }
              />
            </div>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <select class="form-control pt-4 pb-4"
              required
              value={newDriver.Gender || ""}
              onChange={(e) => setNewDriver({ ...newDriver, Gender: e.target.value })}
              >
                <option value="Male">Male </option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div class="form-group col-lg-6 p-1">
              <div class="input-group">
                <input
                  type="file"
                  class="form-control pt-4 pb-4"
                  id="inputGroupFile02"
                onChange={(e) =>
                  setNewDriver({ ...newDriver, picture: e.target.value })
                }
                />
                <label class="input-group-text" for="inputGroupFile02">
                  Upload Profile Photo
                </label>
              </div>
            </div>
          </div>
          <div class="form-group col-lg-12 p-3 ">
            <h5>Vehical Information</h5>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter Vehical Number"
                id="vehiclenumber"
                required
                pattern="[A-Za-z]+"
                value={newDriver.vehicalnumber || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, vehicalnumber: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Enter Vehical Type"
                id="vehicaltype"
                required
                pattern="[A-Za-z]+"
                value={newDriver.vehicaltype || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, vehicaltype: e.target.value })
                }
              />
            </div>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Vehical Model"
                id="vehicalmodel"
                required
                pattern="[A-Za-z]+"
                value={newDriver.vehicalmodel || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, vehicalmodel: e.target.value })
                }
              />
            </div>
            <div class="form-group col-lg-6 p-1">
              <input
                type="text"
                class="form-control pt-4 pb-4"
                placeholder="Seating Capacity"
                id="seatingcapacity"
                required
                pattern="[A-Za-z]+"
                value={newDriver.seatingcapacity || ""}
                onChange={(e) =>
                  setNewDriver({ ...newDriver, seatingcapacity: e.target.value })
                }
              />
            </div>
          </div>
          <div className="row">
            <div class="form-group col-lg-6 p-1">
              <div class="input-group">
                <input
                  type="file"
                  class="form-control pt-4 pb-4"
                  id="inputGroupFile00"
                onChange={(e) =>
                  setNewDriver({ ...newDriver, vehicaldocs: e.target.value })
                }
                />
                <label class="input-group-text" for="inputGroupFile02">
                  Upload Vehical Documents
                </label>
              </div>
            </div>
          </div>
          <div class="form-group col-lg-12 p-1 pb-3">
            <button type="submit" className="form-control btn btn-success "
            >
              <h5> Add Driver</h5>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddDrivers;
