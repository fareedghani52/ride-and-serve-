import React, { useState } from "react";
import Chart from "react-apexcharts";
const Charts = () => {
  const [state] = useState({
    options: {
      chart: {
        id: "basic-bar",
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "jun",
          "july",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
      },
    },
    series: [
      {
        name: "series-1",
        data: [0, 0, 30, 40, 45, 50, 49, 60, 70, 91],
      },
    ],
  });
  const [pie] = useState({
    options: {},
    series: [44, 55, 41, 17, 15],
    labels: ["A", "B", "C", "D", "E"],
  });
  return (
    <div className="d-flex align-item-center justify-content-center  flex-wrap">
      <Chart
        options={state.options}
        series={state.series}
        type="bar"
        width="400"
        style={{ marginRight: "10px" }}
      />

      <Chart
        options={state.options}
        series={state.series}
        type="line"
        width="400"
        style={{ marginRight: "20px" }}
      />

      <Chart
        options={pie.options}
        series={pie.series}
        type="donut"
        width="400"
      />
    </div>
  );
};

export default Charts;
