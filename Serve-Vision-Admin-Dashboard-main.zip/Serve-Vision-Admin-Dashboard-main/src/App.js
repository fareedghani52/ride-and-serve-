import "./App.css";
import Navbar from "./Components/Navbar";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard";

import Drivers from "./pages/Drivers";
import Users from "./pages/Users";
import Rides from "./pages/Rides";
import FareDetail from "./pages/FareDetail";
import AddDrivers from "./pages/AddDrivers";
function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/drivers" element={<Drivers />} />
          <Route path="/users" element={<Users />} />
          <Route path="/faredetails" element={<FareDetail />} />
          <Route path="/rides" element={<Rides />} />
          <Route path="/add-drivers" element={<AddDrivers />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
